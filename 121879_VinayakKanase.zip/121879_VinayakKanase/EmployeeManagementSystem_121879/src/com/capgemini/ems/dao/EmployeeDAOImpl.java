/*****************************************************************************************************
File : EmployeeDAOImpl.java
Name : Vinayak Kanase. 
Description : Data Access Objects
Created Date : 31/03/2017
******************************************************************************************************/
package com.capgemini.ems.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import oracle.net.aso.q;

import org.springframework.stereotype.Repository;

import com.capgemini.ems.entities.Employee;
import com.capgemini.ems.exception.EmployeeException;


@Repository("employeeDAO")
public class EmployeeDAOImpl implements IEmployeeDAO 
{
	@PersistenceContext
	private EntityManager entityManager ;
	
	public EmployeeDAOImpl() {
		// TODO Auto-generated constructor stub
	}

	public EmployeeDAOImpl(EntityManager entityManager) {
		super();
		this.entityManager = entityManager;
	}

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public int addEmployee(Employee employee) throws EmployeeException 
	{
		int id = -1;
		try
		{
			entityManager.persist(employee);
			id = employee.getEmployee_code() ;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new EmployeeException("Something went wrong while inserting record");
		}
		return id;
	}

	@Override
	public List<Employee> getAllEmployees() throws EmployeeException {
		
		List<Employee> empList = new ArrayList<Employee>();
		try
		{
			TypedQuery<Employee> query = entityManager.createQuery("select emp from Employee emp", Employee.class) ;
			empList = query.getResultList() ;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new EmployeeException(" Problem while fetching List of employees")  ;
		}
		
		if(empList == null || empList.isEmpty())
		{
			throw new EmployeeException("No Employees Found");
		}
		return empList;
	}
	
	
}

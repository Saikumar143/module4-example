package com.capgemini.ems.dao;

import java.util.List;

import com.capgemini.ems.entities.Employee;
import com.capgemini.ems.exception.EmployeeException;

public interface IEmployeeDAO 
{
	public int addEmployee(Employee employee) throws EmployeeException ;
	public List<Employee> getAllEmployees() throws EmployeeException ;
}

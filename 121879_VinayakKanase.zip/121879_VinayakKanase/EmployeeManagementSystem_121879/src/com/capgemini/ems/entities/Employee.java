package com.capgemini.ems.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="employee")
public class Employee 
{
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "mygen")
	@SequenceGenerator(name="mygen" , sequenceName = "hibernate_sequence" , initialValue=1000)
	private int employee_code ;
	
	@NotEmpty(message="Name Cannot be Left Empty")
	@Size(min=5 , max=40 , message="Name must be minimum of 5 amd mximum 40 in length")
	private String employee_name ;
	
	@NotEmpty(message="Please Select Gender")
	private String employee_gender ;
	
	@NotEmpty(message="Please Select Designation")
	private String designation_name ;
	
	
	@NotEmpty(message="Email cannot be left blank")
	@Pattern(regexp= "[A-Za-z0-9]+@[A-Za-z0-9.-]+[.][A-Za-z]{2,4}", message="Email Should be of format eg:abc@abc.com")
	private String employee_email ;
	
	
	//@Pattern(regexp="[7-9]{1}[0-9]{9}", message="Phone no should be of correct format i.e start with (7/8/9) and length must be of 10 digits")
	
	@NotEmpty(message="Phone cannot be empty")
	@Size(min=10,max=10,message="Phone No Sould be of 10 digits")
	private String employee_phone ;
	
	public Employee() {
		// TODO Auto-generated constructor stub
	}

	public Employee(int employee_code, String employee_name,
			String employee_gender, String designation_name,
			String employee_email, String employee_phone) {
		super();
		this.employee_code = employee_code;
		this.employee_name = employee_name;
		this.employee_gender = employee_gender;
		this.designation_name = designation_name;
		this.employee_email = employee_email;
		this.employee_phone = employee_phone;
	}

	public Employee(String employee_name, String employee_gender,
			String designation_name, String employee_email, String employee_phone) {
		super();
		this.employee_name = employee_name;
		this.employee_gender = employee_gender;
		this.designation_name = designation_name;
		this.employee_email = employee_email;
		this.employee_phone = employee_phone;
	}

	public int getEmployee_code() {
		return employee_code;
	}

	public void setEmployee_code(int employee_code) {
		this.employee_code = employee_code;
	}

	public String getEmployee_name() {
		return employee_name;
	}

	public void setEmployee_name(String employee_name) {
		this.employee_name = employee_name;
	}

	public String getEmployee_gender() {
		return employee_gender;
	}

	public void setEmployee_gender(String employee_gender) {
		this.employee_gender = employee_gender;
	}

	public String getDesignation_name() {
		return designation_name;
	}

	public void setDesignation_name(String designation_name) {
		this.designation_name = designation_name;
	}

	public String getEmployee_email() {
		return employee_email;
	}

	public void setEmployee_email(String employee_email) {
		this.employee_email = employee_email;
	}

	public String getEmployee_phone() {
		return employee_phone;
	}

	public void setEmployee_phone(String employee_phone) {
		this.employee_phone = employee_phone;
	}

	@Override
	public String toString() {
		return "Employee [employee_code=" + employee_code + ", employee_name="
				+ employee_name + ", employee_gender=" + employee_gender
				+ ", designation_name=" + designation_name
				+ ", employee_email=" + employee_email + ", employee_phone="
				+ employee_phone + "]";
	}
	
	
}

package com.capgemini.ems.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.ems.dao.IEmployeeDAO;
import com.capgemini.ems.entities.Employee;
import com.capgemini.ems.exception.EmployeeException;


@Service("bookingService")
@Transactional
public class EmployeeServiceImpl implements IEmployeeService 
{
	@Autowired
	IEmployeeDAO employeeDAO ;
	
	public EmployeeServiceImpl() {
		// TODO Auto-generated constructor stub
	}

	public EmployeeServiceImpl(IEmployeeDAO employeeDAO) {
		super();
		this.employeeDAO = employeeDAO;
	}

	public IEmployeeDAO getEmployeeDAO() {
		return employeeDAO;
	}

	public void setEmployeeDAO(IEmployeeDAO employeeDAO) {
		this.employeeDAO = employeeDAO;
	}

	@Override
	public String toString() {
		return "EmployeeServiceImpl [employeeDAO=" + employeeDAO + "]";
	}

	@Override
	public int addEmployee(Employee employee) throws EmployeeException {
		// TODO Auto-generated method stub
		return employeeDAO.addEmployee(employee);
	}

	@Override
	public List<Employee> getAllEmployees() throws EmployeeException {
		// TODO Auto-generated method stub
		return employeeDAO.getAllEmployees();
	}  
	
	
}

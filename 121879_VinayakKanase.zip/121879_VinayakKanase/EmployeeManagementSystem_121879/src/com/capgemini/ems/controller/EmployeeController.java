/*****************************************************************************************************
File : EmployeeController.java
Name : Vinayak Kanase. 
Description : Controller Class
Created Date : 31/03/2017
******************************************************************************************************/
package com.capgemini.ems.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import oracle.net.aso.e;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.capgemini.ems.entities.Employee;
import com.capgemini.ems.service.IEmployeeService;

@Controller
public class EmployeeController 
{
	@Autowired
	private IEmployeeService employeeService ;
	
	public EmployeeController() {
		// TODO Auto-generated constructor stub
	}

	public EmployeeController(IEmployeeService employeeService) {
		super();
		this.employeeService = employeeService;
	}

	public IEmployeeService getEmployeeService() {
		return employeeService;
	}

	public void setEmployeeService(IEmployeeService employeeService) {
		this.employeeService = employeeService;
	}
	
	// getting AddEmployee Page
	@RequestMapping("addEmployee")
	public String getAddEmployeePage(Model model)
	{
		// We are using list because we want to populate this data in form 
		List<String> genders = new ArrayList<String>();
		genders.add("Male") ;
		genders.add("Female") ;
		
		
		List<String> designations = new ArrayList<String>();
		designations.add("Software Engineer") ;
		designations.add("Senior Software Engineer") ;
		designations.add("Team Lead") ;
		designations.add("Manager") ;
		
		
		model.addAttribute("genders", genders) ;
		model.addAttribute("designations", designations) ;
		model.addAttribute("employee" , new Employee()) ;
		
		return "AddEmployeePage" ;
	}
	
	
	//After submitting we are processing the data and storing data in database 
	//@valid is used to check validation
	//BindingResult is used to store errors
	@RequestMapping("processAddEmployee")
	public String processAddEmployee(@ModelAttribute("employee") @Valid Employee employee , BindingResult result ,
			Model model) 
	{
		//Checking if we have error if true then going to same page 
		if(result.hasErrors() == true)
		{
			List<String> genders = new ArrayList<String>();
			genders.add("Male") ;
			genders.add("Female") ;
			
			
			List<String> designations = new ArrayList<String>();
			designations.add("Software Engineer") ;
			designations.add("Senior Software Engineer") ;
			designations.add("Team Lead") ;
			designations.add("Manager") ;
			
			
			model.addAttribute("genders", genders) ;
			model.addAttribute("designations", designations) ;
			model.addAttribute("employee" , employee) ;
			
			return "AddEmployeePage" ;
		}
		
		int id = -1;
		try
		{
			id = employeeService.addEmployee(employee) ;
		}
		catch(Exception e)
		{
			model.addAttribute("errMsg", " Error " + e.getMessage()) ;
			return "ErrorPage" ;
		}
		
		model.addAttribute("message", "Employee Added successfully and the employee code is " + id ) ;
		return "SuccessPage" ;
		
		
	}
	
	//Viewing All Employee In jsp page
	@RequestMapping("viewAllEmployee")
	public String getAllEmployeePage(Model model)
	{
		List<Employee> empList = new ArrayList<>(); 
		try
		{
			empList = employeeService.getAllEmployees() ;
		}
		catch(Exception e)
		{
			model.addAttribute("errMsg", "Error " + e.getMessage()) ;
			return "ErrorPage" ;
		}
		
		model.addAttribute("empList", empList) ;
		return "ViewAllEmployeePage" ;
	}
	
}

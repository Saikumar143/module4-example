select * from EMPLOYEE ;

drop table employee ;

create table employee
(
	employee_code number primary key ,
	employee_name varchar2(50) ,
	employee_gender varchar2(10) ,
	designation_name varchar2(30) ,
	employee_email varchar2(30),
	employee_phone number(10)
)

select hibernate_sequence.nextval from dual ;

delete from employee ;

drop sequence Labg103trg24.hibernate_sequence ;

create sequence hibernate_sequence start with 1000 ;